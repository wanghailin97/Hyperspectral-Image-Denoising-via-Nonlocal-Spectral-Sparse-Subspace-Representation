function HSI_noise = Add_Noise(HSI_true, gaussian_ratio, sparse_ratio, stripe_ratio, deadline_ratio)
% add noise, including gaussian noise, sparse (salt & pepper) noise, stripe noise and deadline noise
 [height, width, band] = size(HSI_true);
 Nway = [height, width, band];
 HSI_noise = HSI_true;

%% add gaussian noise
for i = 1:band
    HSI_noise(:, :, i) = imnoise(HSI_noise(:, :, i), 'gaussian', 0, gaussian_ratio^2);
end

%% add sparse noise
for i = 1:band
    HSI_noise(:, :, i) = imnoise(HSI_noise(:, :, i), 'salt & pepper', sparse_ratio);
end

%% add stripes
add_band_s = randperm(band, ceil(stripe_ratio * band));
for i = 1:length(add_band_s)
    stripenum = randperm(10,1)+5;
    locolumn    = randperm(Nway(2),stripenum);
    HSI_noise(:,locolumn,add_band_s(i)) = 0.2 * rand(1) + 0.6;
end

%% add deadlines
add_band_d = randperm(band, ceil(deadline_ratio * band));
for i = 1:length(add_band_d)
    deadlinenum = randperm(5,1) + 5;
    locolumn    = randperm(Nway(2) - 2, deadlinenum);
    an          = funrand(3, deadlinenum);
    HSI_noise(:, locolumn(an==1), add_band_d(i)) = 0; 
    HSI_noise(:, locolumn(an==2), add_band_d(i)) = 0;
    HSI_noise(:, locolumn(an==2) + 1, add_band_d(i)) = 0;
    HSI_noise(:, locolumn(an==3), add_band_d(i)) = 0;
    HSI_noise(:, locolumn(an==3) + 1, add_band_d(i)) = 0; 
    HSI_noise(:, locolumn(an==3) + 2, add_band_d(i)) = 0; 
end
end

function an = funrand(a,n)
for i = 1:n
    an(i) = randperm(a, 1);
end
end
