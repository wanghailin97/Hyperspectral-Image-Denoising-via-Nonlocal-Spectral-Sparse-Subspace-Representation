function an=funrand(a,n)
for i=1:n
    an(i)=randperm(a,1);
end
