%==========================================================================
% This script compares multi-spectral imagery (MSI) noise removal methods
% listed as follows:
%   1. NNM
%   2. WNNM
%   3. LRMR
%   4. BM4D
%   5. TDL
%   6. WSNM
%   7. LRTV
%   8. LRTDTV
%   9. E3DTV
%   10. RPCA
%   11. VBRPCA
%   12. TRPCA
%   13. KBR_RPCA
%   14. CTV
%   15. HCTV
%   16. HCTV_Mixed
%   17. TCTV_U_denoising
%==========================================================================

%% 1: initiation
% 1.1 ========== DATA SET==========
clear all;clc;
addpath(genpath('E:\近期工作\二阶CTV\有关代码\Enhanced-3DTV-master'));
addpath(genpath('E:\近期工作\二阶CTV\有关代码\Enhanced-3DTV-master'));
addpath(genpath('E:\近期工作\二阶CTV\有关代码\Enhanced-3DTV-master'));
addpath(genpath('E:\近期工作\二阶CTV\实验\CTV-RPCA'));
addpath(genpath('C:\Users\admin\Desktop\tCTV-U-denoising'));
%% load data
% load simu_indian
% Ohsi       = simu_indian;
load pure_DCMall;
Ohsi = X;

[M,N,p]   = size(Ohsi);
Ohsi   = Ohsi(1:100,1:100,:);

% 1.3 ========== NOISE PATTERN SET==========
noiselevel = 0.02*ones(1,224); 
gausssigma = mean(noiselevel);
spsigma    = 0;
% ------------------------ Simulation experiment --------------------------
%% Gaussian noise
% for i = 1:p
%      Nhsi(:,:,i)=Ohsi(:,:,i)+noiselevel(i)*randn(M,N);
% end

% Nhsi = GetNoise(Ohsi, 0.02, 0.1); % add noise
% 1.4 ========== GCP ACCELARATE SET==========
%     if isempty(gcp)
%         parpool('local',4,'IdleTimeout', 6000); % If your computer's memory is less than 8G, do not use more than 4 workers.
%     end 
gaussian_ratio = 0;
sparse_ratio = 0.3;
stripe_ratio = 0;
deadline_ratio = 0;
Nhsi = Add_Noise(Ohsi, gaussian_ratio, sparse_ratio, stripe_ratio, deadline_ratio);
%% 2 START RUNNING THE METHOD
options.STATUS_NNM  = 0;
options.STATUS_WNNM = 0;
options.STATUS_LRMR = 0;
options.STATUS_BM4D = 0;
options.STATUS_TDL  = 0;
options.STATUS_WSNM = 0;
options.STATUS_LRTV = 0;
options.STATUS_LRTDTV = 0;
options.STATUS_Enhanced3DTV  = 1;
options.STATUS_RPCA  = 0;
options.STATUS_VBRPCA  = 0;
options.STATUS_TRPCA  = 0;
options.STATUS_KBR_RPCA  = 0;
options.STATUS_CTV  = 1;
options.STATUS_HCTV  = 1;
options.STATUS_HCTV_Mixed  = 0;
options.STATUS_TCTV_U_denoising  = 0;
options.spsigma = spsigma;
options.gausssigma = gausssigma;
if spsigma ~=0
    options.gausssigma = 0;
end
[mpsnr,mssim,ergas,Time]=RunAllMethod(options,Ohsi,Nhsi);




