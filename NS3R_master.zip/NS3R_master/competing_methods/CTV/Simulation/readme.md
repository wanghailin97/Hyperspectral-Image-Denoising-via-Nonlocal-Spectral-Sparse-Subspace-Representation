# CTV-\sqrt{PCP} and CTV-SPCP

## run "test_demo.m"
    One of the results is
        mode     \sqrt{PCP}    CTV-\sqrt{PCP}   SPCP    CTV-SPCP  Time
        P         30.0108      25.4172        32.7343   25.7899   1.4
        G         28.9021      24.7441        31.8101   25.0555   1.2
        B         30.4651      26.7857        33.3720   27.2956   1.2
        U         29.0604      24.8513        31.0417   24.4517   1.2
## run "plot_vary_curve.m"
        - plot the decay ratio varying sparsity
        - plot the rmse varing sigma
        - plot the rmse varing size

